package com.example.storyapp.adapter

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.util.Pair
import androidx.core.app.ActivityOptionsCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.storyapp.R
import com.example.storyapp.data.ListStoryItem
import com.example.storyapp.databinding.ListItemBinding
import com.example.storyapp.detail.DetailActivity
import com.example.storyapp.utils.Utils
import java.util.*

class ListStoryAdapter : PagingDataAdapter<ListStoryItem, ListStoryAdapter.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStoryItem>() {
            override fun areItemsTheSame(
                oldItem: ListStoryItem,
                newItem: ListStoryItem
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: ListStoryItem,
                newItem: ListStoryItem
            ): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = getItem(position)
        if (data != null) {
            holder.bind(data)
        }
    }

    inner class ViewHolder(private var binding: ListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        @RequiresApi(Build.VERSION_CODES.O)
        fun bind(story: ListStoryItem) {
            with(binding) {
                Glide.with(itemView)
                    .load(story.photoUrl)
                    .placeholder(R.drawable.ic_blank_image)
                    .error(R.drawable.ic_broken_image)
                    .into(imgPhoto)
                txtUsername.text = story.name
                txtDescription.text = story.description
                txtTime.text =
                    binding.root.resources.getString(
                        R.string.creat_time,
                        Utils.formatDate(story.createdAt, TimeZone.getDefault().id)
                    )
                imgPhoto.setOnClickListener {
                    val intent = Intent(it.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_DATA, story)

                    val optionsCompat: ActivityOptionsCompat =
                        ActivityOptionsCompat.makeSceneTransitionAnimation(
                            imgPhoto.context as Activity,
                            Pair(imgPhoto, "story"),
                            Pair(txtUsername, "username"),
                            Pair(txtDescription, "description"),
                            Pair(txtTime, "time")
                        )
                    imgPhoto.context.startActivity(intent, optionsCompat.toBundle())
                }
            }
        }
    }
}