package com.example.storyapp.data


data class AddNewStory(
    val error: Boolean? = null,
    val message: String? = null
)
