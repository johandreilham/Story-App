package com.example.storyapp.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize


data class GetAllStories(
    val listStory: List<ListStoryItem>,
    val error: Boolean,
    val message: String
)

@Parcelize
@Entity(tableName = "story")
data class ListStoryItem(
    val photoUrl: String,
    val createdAt: String,
    val name: String,
    val description: String,
    val lon: Double,
    @PrimaryKey
    @field:SerializedName("id")
    val id: String,
    val lat: Double
) : Parcelable

