package com.example.storyapp.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.storyapp.api.Api
import com.example.storyapp.database.StoryDatabase
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody
import okhttp3.RequestBody
import kotlin.Exception

class StoryPreferences (private val apiService: Api, private val storyDatabase: StoryDatabase) {

    fun getStories(token: String): Flow<PagingData<ListStoryItem>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            remoteMediator = StoryRemoteMediator(storyDatabase, apiService, token),
            pagingSourceFactory = {
                storyDatabase.storyDao().getStory()
            }
        ).flow
    }


    fun uploadStory(
        token: String,
        imageMultipart: MultipartBody.Part,
        desc: RequestBody,
        lat: RequestBody?,
        lon: RequestBody?
    ): LiveData<Result<AddNewStory>> = liveData {
        emit(Result.Loading)
        try {
            val client = apiService.uploadStory("Bearer $token", imageMultipart, desc, lat, lon)
            emit(Result.Success(client))
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d("StoryPreferences", "uploadStory: ${e.message.toString()} ")
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getStoriesLocation(token: String): LiveData<Result<GetAllStories>> = liveData {
        emit(Result.Loading)
        try {
            val client = apiService.getStories("Bearer $token", location = 1)
            emit(Result.Success(client))
        }
        catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    companion object {
        @Volatile
        private var instance: StoryPreferences? = null
        fun getInstance(
            apiService: Api,
            storyDatabase: StoryDatabase
        ): StoryPreferences =
            instance ?: synchronized(this) {
                instance ?: StoryPreferences(apiService, storyDatabase)
            }.also { instance = it }
    }
}