package com.example.storyapp.data


data class UserRegister(
    val error: Boolean? = null,
    val message: String? = null
)

