package com.example.storyapp.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.storyapp.data.ListStoryItem
import com.example.storyapp.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val story = intent.getParcelableExtra<ListStoryItem>(EXTRA_DATA)
        binding.apply {
            txtUsername.text = story?.name
            txtDescription.text = story?.description
            Glide.with(this@DetailActivity)
                .load(story?.photoUrl)
                .into(imgPhoto)
        }
    }

    companion object {
        const val EXTRA_DATA = "extra_data"
    }
}