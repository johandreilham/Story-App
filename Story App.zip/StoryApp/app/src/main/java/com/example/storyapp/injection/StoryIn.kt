package com.example.storyapp.injection

import android.content.Context
import com.example.storyapp.api.ApiConfig
import com.example.storyapp.data.StoryPreferences
import com.example.storyapp.database.StoryDatabase

object StoryIn {
    fun provideRepository(context: Context): StoryPreferences {
        val apiService = ApiConfig.getApi()
        val database = StoryDatabase.getInstance(context)
        return StoryPreferences(apiService, database)
    }
}