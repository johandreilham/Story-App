package com.example.storyapp.injection

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.example.storyapp.api.ApiConfig
import com.example.storyapp.data.UserPreferences

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

object UserIn {
    fun provideRepository(context: Context): UserPreferences {
        val apiService = ApiConfig.getApi()
        return UserPreferences.getInstance(context.dataStore, apiService)
    }
}