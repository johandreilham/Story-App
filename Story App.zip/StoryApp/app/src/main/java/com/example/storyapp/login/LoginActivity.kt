package com.example.storyapp.login

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.R
import com.example.storyapp.data.Result
import com.example.storyapp.databinding.ActivityLoginBinding
import com.example.storyapp.main.MainActivity
import com.example.storyapp.utils.animationProgressBar
import com.example.storyapp.viewmodel.ViewModelFactory

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setView()
        setViewModel()
        setAction()
        playAnimation()
    }

    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imgLogo, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.txtMailgram, View.ALPHA, 1f).setDuration(100)
        val desc = ObjectAnimator.ofFloat(binding.txtJudul1, View.ALPHA, 1f).setDuration(100)
        val desc2 = ObjectAnimator.ofFloat(binding.txtJudul2, View.ALPHA, 1f).setDuration(100)

        val email1 = ObjectAnimator.ofFloat(binding.txtEmail, View.ALPHA, 1f).setDuration(100)
        val email2 = ObjectAnimator.ofFloat(binding.txtInputEmail, View.ALPHA, 1f).setDuration(100)

        val together1 = AnimatorSet().apply {
            playTogether(email1, email2)
        }

        val pw1 = ObjectAnimator.ofFloat(binding.txtPassword, View.ALPHA, 1f).setDuration(100)
        val pw2 = ObjectAnimator.ofFloat(binding.txtInputPassword, View.ALPHA, 1f).setDuration(100)

        val together2 = AnimatorSet().apply {
            playTogether(pw1, pw2)
        }

        val login = ObjectAnimator.ofFloat(binding.btnLogin, View.ALPHA, 1f).setDuration(100)

        AnimatorSet().apply {
            playSequentially(title, desc, desc2, together1, together2, login)
            start()
        }
    }

    private fun setView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setViewModel() {
        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        loginViewModel = ViewModelProvider(this, factory)[LoginViewModel::class.java]

        loginViewModel.getToken().observe(this) { token ->
            if (token.isNotEmpty()) {
                startActivity(Intent(this,MainActivity::class.java))
                finish()
            }
        }
    }

    private fun setAction() {
        binding.btnLogin.setOnClickListener {
            login()
        }
    }

    private fun login() {
        binding.apply {
            val email = txtInputEmail.text.toString().trim()
            val password = txtInputPassword.text.toString().trim()
            when {
                email.isEmpty() -> {
                    txtInputEmail.error = resources.getString(R.string.message, "email")
                }
                password.isEmpty() -> {
                    txtInputPassword.error = resources.getString(R.string.message, "password")
                }
                else -> {
                    loginViewModel.login(email, password).observe(this@LoginActivity) { result ->
                        if (result != null) {
                            when (result) {
                                is Result.Loading -> {
                                    showLoading(true)
                                }
                                is Result.Success -> {
                                    showLoading(false)
                                    val user = result.data
                                    if (user.error == true) {
                                        Toast.makeText(this@LoginActivity, user.message, Toast.LENGTH_SHORT).show()
                                    } else {
                                        val token = user.loginResult?.token ?: ""
                                        loginViewModel.setToken(token, true)
                                    }
                                }
                                is Result.Error -> {
                                    showLoading(false)
                                    Toast.makeText(this@LoginActivity, resources.getString(R.string.login_error), Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    private fun showLoading(isLoading: Boolean) {
        binding.apply {
            txtInputEmail.isEnabled = !isLoading
            txtInputPassword.isEnabled = !isLoading
            btnLogin.isEnabled = !isLoading

            if (isLoading) {
                progressBar.animationProgressBar(true)
            } else {
                progressBar.animationProgressBar(false)
            }
        }
    }
}