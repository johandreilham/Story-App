package com.example.storyapp.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.storyapp.data.ListStoryItem
import com.example.storyapp.data.StoryPreferences
import com.example.storyapp.data.UserPreferences
import kotlinx.coroutines.launch

class MainViewModel (private val userRepo: UserPreferences, private val storyRepo: StoryPreferences) :
    ViewModel() {

    fun getToken(): LiveData<String> {
        return userRepo.getToken().asLiveData()
    }

    fun isLogin(): LiveData<Boolean> {
        return userRepo.isLogin().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            userRepo.logout()
        }
    }

    fun getStories(token: String): LiveData<PagingData<ListStoryItem>> {
        return storyRepo.getStories(token).cachedIn(viewModelScope).asLiveData()
    }

}