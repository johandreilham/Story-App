package com.example.storyapp.maps

import androidx.lifecycle.ViewModel
import com.example.storyapp.data.StoryPreferences

class MapsViewModel(private val storyRepo: StoryPreferences) : ViewModel(){

    fun getStories(token: String) = storyRepo.getStoriesLocation(token)

}