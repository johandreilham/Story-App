package com.example.storyapp.signup

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.R
import com.example.storyapp.data.Result
import com.example.storyapp.databinding.ActivitySignupBinding
import com.example.storyapp.utils.animationProgressBar
import com.example.storyapp.viewmodel.ViewModelFactory


class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var signupViewModel: SignupViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setView()
        setViewModel()
        setAction()
        playAnimation()

    }

    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imgLogo, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.txtMailgram, View.ALPHA, 1f).setDuration(100)
        val desc = ObjectAnimator.ofFloat(binding.txtJudul1, View.ALPHA, 1f).setDuration(100)
        val desc2 = ObjectAnimator.ofFloat(binding.txtJudul2, View.ALPHA, 1f).setDuration(100)

        val name1 = ObjectAnimator.ofFloat(binding.txtName, View.ALPHA, 1f).setDuration(100)
        val name2 = ObjectAnimator.ofFloat(binding.txtInputName, View.ALPHA, 1f).setDuration(100)

        val together1 = AnimatorSet().apply {
            playTogether(name1, name2)
        }

        val email1 = ObjectAnimator.ofFloat(binding.txtEmail, View.ALPHA, 1f).setDuration(100)
        val email2 = ObjectAnimator.ofFloat(binding.txtInputEmail, View.ALPHA, 1f).setDuration(100)

        val together2 = AnimatorSet().apply {
            playTogether(email1, email2)
        }

        val pw1 = ObjectAnimator.ofFloat(binding.txtPassword, View.ALPHA, 1f).setDuration(100)
        val pw2 = ObjectAnimator.ofFloat(binding.txtInputPassword, View.ALPHA, 1f).setDuration(100)

        val together3 = AnimatorSet().apply {
            playTogether(pw1, pw2)
        }

        val register = ObjectAnimator.ofFloat(binding.btnSignup, View.ALPHA, 1f).setDuration(100)

        AnimatorSet().apply {
            playSequentially(title, desc, desc2, together1, together2, together3, register)
            start()
        }
    }

    private fun setView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setViewModel() {
        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        signupViewModel = ViewModelProvider(this, factory)[SignupViewModel::class.java]
    }

    private fun setAction() {
        binding.apply {
            btnSignup.setOnClickListener {
                val name = txtInputName.text.toString().trim()
                val email = txtInputEmail.text.toString().trim()
                val password = txtInputPassword.text.toString().trim()
                when {
                    name.isEmpty() -> {
                        txtInputName.error = resources.getString(R.string.message, "name")
                    }
                    email.isEmpty() -> {
                        txtInputEmail.error = resources.getString(R.string.message, "email")
                    }
                    password.isEmpty() -> {
                        txtInputPassword.error = resources.getString(R.string.message, "password")
                    }
                    else -> {
                        signupViewModel.register(name, email, password).observe(this@SignupActivity) { result ->
                            if (result != null) {
                                when (result) {
                                    is Result.Loading -> {
                                        showLoading(true)
                                    }
                                    is Result.Success -> {
                                        showLoading(false)
                                        val user = result.data
                                        if (user.error == true) {
                                            Toast.makeText(this@SignupActivity, user.message, Toast.LENGTH_SHORT).show()
                                        } else {
                                            AlertDialog.Builder(this@SignupActivity).apply {
                                                setTitle("Yeah!")
                                                setMessage("Your account successfully created!")
                                                setPositiveButton("Next") { _, _ ->
                                                    finish()
                                                }
                                                create()
                                                show()
                                            }
                                        }
                                    }
                                    is Result.Error -> {
                                        showLoading(false)
                                        Toast.makeText(this@SignupActivity, resources.getString(R.string.signup_error), Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                    }
                    }
                }
            }
        }

    private fun showLoading(isLoading: Boolean) {
        binding.apply {
            txtInputName.isEnabled = !isLoading
            txtInputEmail.isEnabled = !isLoading
            txtInputPassword.isEnabled = !isLoading
            btnSignup.isEnabled = !isLoading

            if (isLoading) {
                progressBar.animationProgressBar(true)
            } else {
                progressBar.animationProgressBar(false)
            }
        }
    }

}
