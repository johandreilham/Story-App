package com.example.storyapp.signup

import androidx.lifecycle.ViewModel
import com.example.storyapp.data.UserPreferences

class SignupViewModel (private val repo: UserPreferences) : ViewModel() {
    fun register(name: String, email: String, password: String) =
        repo.register(name, email, password)
}