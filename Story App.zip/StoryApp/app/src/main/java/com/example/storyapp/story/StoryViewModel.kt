package com.example.storyapp.story

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.storyapp.data.StoryPreferences
import com.example.storyapp.data.UserPreferences
import okhttp3.MultipartBody
import okhttp3.RequestBody

class StoryViewModel (private val userRepo: UserPreferences, private val storyRepo: StoryPreferences) :
    ViewModel() {

    fun getToken(): LiveData<String> {
        return userRepo.getToken().asLiveData()
    }

    fun uploadStory(token: String,
                    imageMultipart: MultipartBody.Part,
                    desc: RequestBody,
                    lat: RequestBody?,
                    lon: RequestBody?
    ) = storyRepo.uploadStory(token, imageMultipart, desc, lat, lon)
}