package com.example.storyapp.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.data.StoryPreferences
import com.example.storyapp.data.UserPreferences
import com.example.storyapp.injection.StoryIn
import com.example.storyapp.injection.UserIn
import com.example.storyapp.main.MainViewModel
import com.example.storyapp.maps.MapsViewModel
import com.example.storyapp.story.StoryViewModel

class StoryViewModelFactory private constructor(
    private val userRepo: UserPreferences,
    private val storyRepo: StoryPreferences
) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(userRepo, storyRepo) as T
            }
            modelClass.isAssignableFrom(StoryViewModel::class.java) -> {
                StoryViewModel(userRepo, storyRepo) as T
            }
            modelClass.isAssignableFrom(MapsViewModel::class.java) -> {
                MapsViewModel(storyRepo) as T
            }
            else -> {
                throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
            }
        }
    }

    companion object {
        @Volatile
        private var instance: StoryViewModelFactory? = null
        fun getInstance(context: Context): StoryViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: StoryViewModelFactory(
                    UserIn.provideRepository(context),
                    StoryIn.provideRepository(context)
                )
            }.also { instance = it }
    }
}